
//use to measure portfolio